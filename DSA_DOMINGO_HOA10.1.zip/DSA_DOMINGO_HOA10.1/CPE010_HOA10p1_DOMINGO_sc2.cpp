#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include "graph.h"

int main()
{
    Graph<unsigned> G =
        create_reference_graph<unsigned>();

    std::cout << "B.1 DFS\n";

    auto dfs = depth_first_search(G);

    for (auto vertex : dfs)
    {
        std::cout << vertex << " ";
    }

    std::cout << "\n\n";
    std::cout << "B.2 BFS\n";

    auto bfs = breadth_first_search(G);

    for (auto vertex : bfs)
    {
        std::cout << vertex << " ";
    }

    std::cout << std::endl;

    return 0;
}
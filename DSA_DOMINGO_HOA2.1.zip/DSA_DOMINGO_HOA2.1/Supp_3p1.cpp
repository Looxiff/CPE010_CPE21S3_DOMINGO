#include <iostream>
#include <string>

//Problem 1:
class Fruit{ 
    private:
        std::string fruitName;
        double fruitPrice;
        int fruitQuantity;

    public: //constructor for fruit.
        Fruit(std::string name, double price, int quantity){
            fruitName = name;
            fruitPrice = price;
            fruitQuantity = quantity;
            std::cout << "class Fruit constructor called." << std::endl;
        }
    
    ~Fruit(){ //destructor for fruit.
        std::cout<< "class Fruit's destructor called" << std::endl;
    }

    Fruit(const Fruit &copyFruit){ // copies contructor of class Fruit.
        fruitName = copyFruit.fruitName;
        fruitPrice = copyFruit.fruitPrice;
        fruitQuantity = copyFruit.fruitQuantity;
        std::cout << "copied class Fruit's contructor." <<std::endl;
    }

    Fruit& operator=(const Fruit &copyFruit){ //copies the assignments of class Fruit.
        fruitName = copyFruit.fruitName;
        fruitPrice = copyFruit.fruitPrice;
        fruitQuantity = copyFruit.fruitQuantity;

        return *this;
    }
    //Functions:
    double calculateSum() {
        return fruitPrice * fruitQuantity;
    }

    void printDetails() {
        std::cout << "Fruit: " << fruitName;
        std::cout << "\nPrice: PHP " << fruitPrice;
        std::cout << "\nQuantity: " << fruitQuantity;
        std::cout << "\nSubtotal: " << calculateSum();
        std::cout << "\n" <<std::endl;
    }
};

class Vegetable{
    private: 
        std::string vegName;
        double vegPrice;
        int vegQuantity;

    public: 
        Vegetable(std::string name, double price, int quantity) {
            vegName = name;
            vegPrice = price;
            vegQuantity = quantity;
            std::cout << "class Vegetable's constructor called" << std::endl;
    }

    ~Vegetable(){
        std::cout <<"class Vegetable's destructor called." << std::endl;
    }

    Vegetable(const Vegetable &copyVegetable){
        vegName = copyVegetable.vegName;
        vegPrice = copyVegetable.vegPrice;
        vegQuantity = copyVegetable.vegQuantity;
        std::cout << "copied class Vegetable's constructor." << std::endl;
    }

    Vegetable& operator=(const Vegetable &copyVegetable){
        vegName = copyVegetable.vegName;
        vegPrice = copyVegetable.vegPrice;
        vegQuantity = copyVegetable.vegQuantity;

        return *this;
    }
    //FUNCTIONS
    double calculateSum() {
        return vegPrice * vegQuantity;
    }

    void printDetails() {
        std::cout << "Vegetable: " << vegName;
        std::cout << "\nPrice: PHP " << vegPrice;
        std::cout << "\nQuantity: " << vegQuantity;
        std::cout << "\nSubtotal: " << calculateSum();
        std::cout << "\n" <<std::endl;
    }
};

//Problem 3:
double totalSum(Fruit *fruitList[], int fruitSize, Vegetable *vegList[], int vegSize) {
    double total = 0;

    for(int i =0; i < fruitSize; i++) {
        total += fruitList[i]->calculateSum();
    }

    for(int i = 0; i < vegSize; i++) {
        total += vegList[i]->calculateSum();
    }

    return total;
}

int main() {
 //Problem 2
    const size_t fruitSize = 2;
    const size_t vegSize = 2;

    Fruit *fruitList[fruitSize];
    Vegetable *vegList[vegSize];

    fruitList[0] = new Fruit("Apple", 10, 7);
    fruitList[1] = new Fruit("Banana", 10, 8);

    vegList[0] = new Vegetable("Broccoli", 60, 12);
    vegList[1] = new Vegetable("Lettuce", 50, 10);

    std::cout << "\n      Jenna's Grocery List      \n" << std::endl;
    std::cout << " Fruits\n" << std::endl;

    for(int i = 0; i < fruitSize; i++){
        fruitList[i]->printDetails();
    }

    std::cout << " Vegetables\n" << std::endl;

    for(int i = 0; i < vegSize; i++){
        vegList[i]->printDetails();
    }
    //Problem 3:
    std::cout << "Total Amount: PHP " <<totalSum(fruitList,fruitSize,vegList,vegSize) << std::endl;

    //Problem 4:
    delete vegList[1];
    vegList[1]= nullptr;

    std::cout << "\nRemoving Lettuce: " << std::endl;
    std::cout << "Updated Total Amount: PHP " << totalSum(fruitList,fruitSize,vegList, 1) << std::endl;

    //deleting the memory assigned
    for(int i = 0; i < fruitSize; i++) {
        delete fruitList[i];
    }

    delete vegList[0];

    return 0;
}

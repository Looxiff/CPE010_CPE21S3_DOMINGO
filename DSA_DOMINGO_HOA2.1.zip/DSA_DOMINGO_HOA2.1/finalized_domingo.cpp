#include <iostream>
#include <string.h>

class Student{
    private:
        std::string studentName;
        int studentAge;

    public:
        // Constructor
        Student(std::string newName = " ", int newAge = 18){
            studentName = std::move(newName);
            studentAge = newAge;
            std::cout << "Constructor Called." << std::endl;
        };

        // Destructor
        ~Student(){
            std::cout << "Destructor Called." << std::endl;
        }

        // Copy Constructor
        Student(const Student &copyStudent){
            std::cout << "Copy Constructor Called" << std::endl;
            studentName = copyStudent.studentName;
            studentAge = copyStudent.studentAge;
        }

        // Display Attributes
        void printDetails() {
            std::cout << this->studentName << " " << this->studentAge << std::endl;
        }
};

int main(){
    const size_t j = 5;

    Student *ptr[j];

    std::string nameList[j] = {"Rodney", "Claidie", "Joma", "Daniel", "Akisha"};
    int ageList[j] = {19, 19, 20, 21, 19};

    for(int i = 0; i < j; i++) { // Loop A
        ptr[i] = new Student(nameList[i], ageList[i]);
    }

    for(int i = 0; i < j; i++) { // Loop B
        ptr[i]->printDetails();
    }

    for(int i = 0; i < j; i++) { // Loop C
        delete ptr[i];
    }

    return 0;
}
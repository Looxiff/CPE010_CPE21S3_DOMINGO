#include <iostream>
#include <queue>

void display(std::queue<char> copyQ);

int main(){
    //create an object
    std::queue<char> myQ;
    
    myQ.push('R');
    myQ.push('O');
    myQ.push('D');
    myQ.push('N');
    myQ.push('E');
    myQ.push('Y');
    display(myQ);
    //try all member functions:
    //empty
    std::cout<<myQ.empty()<<std::endl;
    //size
    std::cout<<myQ.size()<<std::endl;
    //front
    std::cout<<myQ.front()<<std::endl;
    //back
    std::cout<<myQ.back()<<std::endl;
    //pop
    myQ.pop();
    //display
    display(myQ);
    //push
    myQ.push('R');
    //display
    display(myQ);
    return 0;
}

void display(std::queue<char> copyQ){
    //creates a copy of the queue that was passed
    std::queue<char> c = copyQ;
    while(!c.empty()){
        std::cout<<" " <<c.front();
        c.pop();
    }
    std::cout<<"\n";
    
}

#include <iostream>
#include "queueLL.h"


int main(){
    qNode<char> *front = nullptr;
    qNode<char>* back = nullptr;
    
    enqueue('R', &front, &back);
    std::cout<<front->data << " " << back->data << std::endl;
    enqueue('O', &front, &back);
    std::cout<<front->data << " " << back->data << std::endl;
    enqueue('D', &front, &back);
    std::cout<<front->data << " " << back->data << std::endl;

    dequeue(&front, &back);
    std::cout<<front->data << " " << back->data << std::endl;
    dequeue(&front, &back);
    std::cout<<front->data << " " << back->data << std::endl;

    checkFront(front);
    checkBack(back);

    display(front);

    return 0;
}
#ifndef QUEUELL_H
#define QUEUELL_H


template <typename T>
class qNode {
public:
    T data;
    qNode<T>* next;
};

// Create new node helper function
template <typename T>
qNode<T>* new_node(T newData) {
    qNode<T>* newNode = new qNode<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}

// Enqueue operation
template <typename T>
void enqueue(T newData, qNode<T>** frontPtr, qNode<T>** backPtr) {
    qNode<T>* newNode = new_node(newData);

    // Inserting into an empty queue
    if (*frontPtr == nullptr && *backPtr == nullptr) {
        *frontPtr = newNode;
        *backPtr = newNode;
    }
    // Inserting an item into a non-empty queue
    else {
        (*backPtr)->next = newNode;
        *backPtr = newNode;
    }
}

// Dequeue operation
template <typename T>
void dequeue(qNode<T>** frontPtr, qNode<T>** backPtr) {
    // Check if queue is empty FIRST
    if (*frontPtr == nullptr && *backPtr == nullptr) {
        std::cout << "List is empty" << std::endl;
        return;
    }

    qNode<T>* deleteNode = *frontPtr;

    // Check if the queue has only 1 node
    if (*frontPtr == *backPtr) {
        *frontPtr = nullptr;
        *backPtr = nullptr;
    } 
    // Queue has more than 1 node
    else {
        *frontPtr = (*frontPtr)->next;
    }

    deleteNode->next = nullptr;
    delete deleteNode;
}

// Check front node data
template <typename T>
void checkFront(qNode<T>* frontPtr) {
    if (frontPtr == nullptr) {
        std::cout << "Queue is empty." << std::endl;
        return;
    }
    std::cout << frontPtr->data << std::endl;
}

// Check back node data
template <typename T>
void checkBack(qNode<T>* backPtr) {
    if (backPtr == nullptr) {
        std::cout << "Queue is empty." << std::endl;
        return;
    }
    std::cout << backPtr->data << std::endl;
}

// Display all nodes in queue
template <typename T>
void display(qNode<T>* frontPtr) {
    if (frontPtr == nullptr) {
        std::cout << "Queue is empty." << std::endl;
        return;
    }

    qNode<T>* temp = frontPtr;
    std::cout << "Display: " << std::endl;
    while (temp != nullptr) {
        std::cout << temp->data << std::endl;
        temp = temp->next;
    }
}

#endif
#include <iostream>
#include "queueArr.h"

int main() {
    QueueArray<int> q(5);

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();

    q.checkFront();
    q.checkBack();

    q.dequeue();
    q.display();

    q.enqueue(40);
    q.enqueue(50);
    q.display();

    std::cout << "Size: " << q.size() << std::endl;

    return 0;
}

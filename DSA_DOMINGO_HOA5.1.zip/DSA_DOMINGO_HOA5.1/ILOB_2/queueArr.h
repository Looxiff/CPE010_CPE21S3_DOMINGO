#ifndef QUEUEARR_H
#define QUEUEARR_H

template <typename T>
class QueueArray {
public:
    T* q_array;
    int q_capacity;
    int q_size;
    int q_front;
    int q_back;

    QueueArray(int capacity = 10) {
        q_capacity = capacity;
        q_array = new T[q_capacity];
        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    ~QueueArray() {
        delete[] q_array;
    }

    bool empty() const {
        return q_size == 0;
    }

    int size() const {
        return q_size;
    }

    void clear() {
        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    void enqueue(T item) {
        if (q_size == q_capacity) {
            std::cout << "Queue overflow!" << std::endl;
            return;
        }
        q_back = (q_back + 1) % q_capacity;
        q_array[q_back] = item;
        q_size++;
    }

    void dequeue() {
        if (empty()) {
            std::cout << "Queue underflow!" << std::endl;
            return;
        }
        q_front = (q_front + 1) % q_capacity;
        q_size--;
    }

    void checkFront() const {
        if (empty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Front: " << q_array[q_front] << std::endl;
    }

    void checkBack() const {
        if (empty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Back: " << q_array[q_back] << std::endl;
    }

    void display() const {
        if (empty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Queue contents: ";
        for (int i = 0; i < q_size; i++) {
            int index = (q_front + i) % q_capacity;
            std::cout << q_array[index] << " ";
        }
        std::cout << std::endl;
    }
};

#endif

#ifndef JOB_H
#define JOB_H

#include <string>

class Job {
public:
    int id;
    std::string user;
    int pages;

    Job(int i, std::string u, int p) : id(i), user(u), pages(p) {}
};

#endif

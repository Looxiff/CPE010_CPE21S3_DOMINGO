#ifndef PRINTER_H
#define PRINTER_H
#include "Job.h"

struct Node {
    Job* job;
    Node* next;
    Node(Job* j) : job(j), next(nullptr) {}
};

class Printer {
public:
    Node* front;
    Node* rear;

    Printer() {
        front = rear = nullptr;
    }

    ~Printer() {
        while (front != nullptr) {
            Node* temp = front;
            front = front->next;
            delete temp->job;
            delete temp;
        }
    }

    void addJob(Job* j) {
        Node* newNode = new Node(j);
        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        std::cout << "Job " << j->id << " added by " << j->user 
                  << " (" << j->pages << " pages)" << std::endl;
    }

    void processJobs() {
        if (front == nullptr) {
            std::cout << "No jobs to process." << std::endl;
            return;
        }
        while (front != nullptr) {
            Node* temp = front;
            std::cout << "Processing Job " << temp->job->id << " from " 
                      << temp->job->user << " (" << temp->job->pages << " pages)" << std::endl;
            front = front->next;
            delete temp->job;
            delete temp;
        }
        rear = nullptr;
    }
};

#endif

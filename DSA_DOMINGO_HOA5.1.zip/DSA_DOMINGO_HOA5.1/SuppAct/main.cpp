#include <iostream>
#include "Job.h"
#include "Printer.h"

int main() {
    Printer printer;

    printer.addJob(new Job(1, "Rodney", 5));
    printer.addJob(new Job(2, "Claidie", 10));
    printer.addJob(new Job(3, "Martin", 3));

    std::cout << "\n--- Processing Jobs ---\n";
    printer.processJobs();

    return 0;
}

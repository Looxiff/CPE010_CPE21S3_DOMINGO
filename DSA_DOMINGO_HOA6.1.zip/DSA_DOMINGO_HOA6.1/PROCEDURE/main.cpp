#include <iostream>
#include <cstdlib>
#include <time.h>
#include "node.h"
#include "searchingAlgo.h"

const int max_size = 50;

int main(){

    //generate 
    int dataset[max_size];
    srand(time(0));
    for(int i=0; i < max_size; i++){
        dataset[i] = rand();
    }
    for (int i = 0; i <max_size; i++){
        std::cout<<dataset[i] << " ";
    }
    std::cout<<std::endl;
    int userInput;
    std::cout<<"what number to search? ";
    std::cin >> userInput;
    //linear search array
    std::cout << "linear search array: " <<std::endl;
    linearSearchArr(max_size, userInput, dataset);

    //binary search array
    std::cout << "binary search array: "<< std::endl;
    binarySearchArr(max_size, userInput, dataset);



    //create linked list: R O D N E Y
    Node<char>* name1 = new_node('R');
    Node<char>* name2 = new_node('O');
    Node<char>* name3 = new_node('D');
    Node<char>* name4 = new_node('N');
    Node<char>* name5 = new_node('E');
    Node<char>* name6 = new_node('Y');

    name1->next = name2;
    name2->next = name3;
    name3->next = name4;
    name4->next = name5;
    name5->next = name6;

    std::cout<< "linked list searching LS: \n";
    linearSearchLL(name1, 'R');
    linearSearchLL(name1, 'r');


    std::cout<< "linked list searching BS:\n";
    binarySearchLL(name1, 'O');
    binarySearchLL(name1, 'o');

    


}
#ifndef NODE_H
#define NODE_H

template <typename T>
class Node{
    public:
        T data;
        Node *next;
};

template <typename T>
Node<T> *new_node(T newData){
    Node<T> *newNode = new Node<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}


template <typename T>
void linearSearchLL(Node<T>* head, T dataFind){
    while(head != nullptr){
        if(head->data == dataFind){
            std::cout<<"Searching is successful. \n";
            return;
        }
        head = head -> next;
    }
    std::cout << "Searching is unsuccessful" <<std::endl;
}

template <typename T>
Node<T>* getMiddle(Node<T>* start, Node<T>* last){

    Node<T>* slow = start;
    Node<T>* fast = start;

    while(fast != last && fast->next != last){
        //slow one step
        slow = slow->next;
        //fast two step
        fast = fast->next;
    }

    return slow;
}


#endif
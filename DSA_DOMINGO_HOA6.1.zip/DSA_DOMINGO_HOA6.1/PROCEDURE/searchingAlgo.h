#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H

template <typename T>
void linearSearchArr(int arrSize, T dataFind , T list[]){
    
    int i = 0;
    
    while(i < arrSize){
        if(dataFind == list[i]){
            std::cout <<"Searching is successful. \n";
            return;
        }
        i++;
    }
    std::cout<<"Searching is unsuccessful" <<std::endl;
}

template <typename T>
void binarySearchLL(Node<T>* start, T dataFind) {

    Node<T>* last = nullptr;

    while (start != last) {
        Node<T>* middle = getMiddle(start, last);

        if (middle == nullptr) return;

        if (middle->data == dataFind) {
            std::cout << "The data was found.\n";
            return;
        }
        else if (middle->data > dataFind) {
            last = middle;
        }
        else {
            start = middle->next;
        }
    }
    std::cout << "searching is unsuccessful.\n";
}

//for array binary search
template <typename T>
void binarySearchArr(int arrSize, T dataFind, T list[]) {
    int low = 0, up = arrSize - 1, middle;
    while (low <= up) {
        middle = (int)(low+up)/2;

        if (dataFind == list[middle]) {
            std::cout << "The searched element is found.\n";
            return;
        }
        else if (dataFind <= list[middle] )
            up = middle - 1;
        else
            low = middle + 1;
    }
    std::cout << "the searched element is not found\n";
}

#endif
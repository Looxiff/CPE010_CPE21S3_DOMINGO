#include <iostream>
#include "node.h"
#include "searchingAlgo.h"

int main() {
    // Problem 1 & 2:
    int sequence[10] = {15, 18, 2, 19, 18, 0, 8, 14, 19, 14};

    Node<int>* seq1 = new_node(15);
    Node<int>* seq2 = new_node(18);
    Node<int>* seq3 = new_node(2);
    Node<int>* seq4 = new_node(19);
    Node<int>* seq5 = new_node(18);
    Node<int>* seq6 = new_node(0);
    Node<int>* seq7 = new_node(8);
    Node<int>* seq8 = new_node(14);
    Node<int>* seq9 = new_node(19);
    Node<int>* seq10 = new_node(14);

    seq1->next = seq2; seq2->next = seq3; seq3->next = seq4;
    seq4->next = seq5; seq5->next = seq6; seq6->next = seq7;
    seq7->next = seq8; seq8->next = seq9; seq9->next = seq10;

    int comparisonsArr = 0;
    int comparisonsLL = 0;

    std::cout << "Problem 1: \n";
    linearSearchArr(10, 18, sequence, comparisonsArr, false);
    linearSearchLL(seq1, 18, comparisonsLL, false);
    std::cout << "Array comparisons: " << comparisonsArr << "\n";
    std::cout << "Linked list comparisons: " << comparisonsLL << "\n";

    std::cout << "Problem 2:\n";
    int countArr = linearSearchArr(10, 18, sequence, comparisonsArr, true);
    int countLL = linearSearchLL(seq1, 18, comparisonsLL, true);
    std::cout << "Array occurrences of 18: " << countArr << "\n";
    std::cout << "Linked list occurrences of 18: " << countLL << "\n";

    // Problem 3:
    int binaryArray[10] = {3, 5, 6, 8, 11, 12, 14, 15, 17, 18};
    std::cout << "Problem 3:\n";
    binarySearchArr(10, 8, binaryArray);

    // Problem 4:
    std::cout << "Problem 4:\n";
    binarySearchArrRecursive(0, 9, 8, binaryArray);

    return 0;
}

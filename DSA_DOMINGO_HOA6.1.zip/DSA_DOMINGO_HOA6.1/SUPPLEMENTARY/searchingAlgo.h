#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H

#include <iostream>
#include "node.h"

// Problem 1 & 2: 
template <typename T>
int linearSearchArr(int arrSize, T dataFind, T list[], int &comparisons, bool countAll = true) {
    int found = 0;
    comparisons = 0;

    for (int i = 0; i < arrSize; i++) {
        comparisons++;
        if (list[i] == dataFind) {
            found++;
            if (!countAll) return found;
        }
    }
    return found;
}

// Problem 1 & 2:
template <typename T>
int linearSearchLL(Node<T>* head, T dataFind, int &comparisons, bool countAll = true) {
    int found = 0;
    comparisons = 0;

    while (head != nullptr) {
        comparisons++;
        if (head->data == dataFind) {
            found++;
            if (!countAll) return found;
        }
        head = head->next;
    }
    return found;
}

// Problem 3:
template <typename T>
bool binarySearchArr(int arrSize, T dataFind, T list[], bool showTrace = true) {
    int low = 0, up = arrSize - 1, mid;

    while (low <= up) {
        mid = (low + up) / 2;

        if (showTrace) {
            std::cout << "Low=" << low << ", Mid=" << mid << ", Up=" << up
                      << " | Value=" << list[mid] << "\n";
        }

        if (list[mid] == dataFind) {
            std::cout << "Search successful.\n";
            return true;
        } else if (dataFind < list[mid]) {
            up = mid - 1;
        } else {
            low = mid + 1;
        }
    }
    std::cout << "Search unsuccessful.\n";
    return false;
}

// Problem 4:
template <typename T>
bool binarySearchArrRecursive(int low, int up, T dataFind, T list[]) {
    if (low > up) {
        std::cout << "Search unsuccessful.\n";
        return false;
    }

    int mid = (low + up) / 2;

    std::cout << "Low=" << low << ", Mid=" << mid << ", Up=" << up
              << " | Value=" << list[mid] << "\n";

    if (list[mid] == dataFind) {
        std::cout << "Search successful.\n";
        return true;
    } else if (dataFind < list[mid]) {
        return binarySearchArrRecursive(low, mid - 1, dataFind, list);
    } else {
        return binarySearchArrRecursive(mid + 1, up, dataFind, list);
    }
}

#endif

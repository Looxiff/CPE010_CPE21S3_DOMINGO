#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorting.h"

void displayArray(int arr[], int size) {
    for(int i = 0; i < size; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}

int main() {
    const int SIZE = 100;
    int dataset[SIZE];

    srand(time(0));

    for(int i = 0; i < SIZE; i++) {
        dataset[i] = rand() % 100;
    }

    displayArray(dataset, SIZE);
    
    std::cout << "\n\nBubble Sort: \n";
    bubbleSort(dataset, SIZE);
    displayArray(dataset, SIZE);

    std::cout << "\n\nSelection Sort: \n";
    selectionSort(dataset, SIZE);
    displayArray(dataset, SIZE);

    std::cout << "\n\nInserstion Sort: \n";
    insertionSort(dataset, SIZE);
    displayArray(dataset, SIZE);

    return 0;
}
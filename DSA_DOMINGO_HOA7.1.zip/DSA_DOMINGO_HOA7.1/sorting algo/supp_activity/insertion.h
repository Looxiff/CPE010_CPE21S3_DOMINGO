#ifndef INSERTION_H
#define INSERTION_H

template <typename T>
void insertionSort(T arr[], int arrSize){
    int k = 1, j;
    T temp;

    while (k < arrSize){
        temp = arr[k];
        j = k - 1; 
        while(j >= 0 && temp < arr[j]){
            arr[j+1] = arr[j];
            j--; 
        }
        arr[j+1] = temp;
        k++;
    }
}

#endif

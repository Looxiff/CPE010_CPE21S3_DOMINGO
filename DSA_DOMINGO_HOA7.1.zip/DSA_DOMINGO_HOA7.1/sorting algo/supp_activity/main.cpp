#include <iostream>
#include <cstdlib>
#include <time.h>
#include "insertion.h" 

void displayArray(int arr[], int size) {
    for(int i = 0; i < size; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}

int main() {
    const int SIZE = 100;
    int votes[SIZE];

    srand(time(0));

    // Generate random votes between 1 and 5
    for(int i = 0; i < SIZE; i++) {
        votes[i] = (rand() % 5) + 1;
    }

    std::cout << "Unsorted Votes:\n";
    displayArray(votes, SIZE);

    // Sort using insertion sort
    insertionSort(votes, SIZE);

    std::cout << "\nSorted Votes:\n";
    displayArray(votes, SIZE);

    // Count votes
    int counts[6] = {0}; // index 1–5 used
    for(int i = 0; i < SIZE; i++) {
        counts[votes[i]]++;
    }

    std::cout << "\nVote Counts:\n";
    for(int c = 1; c <= 5; c++) {
        std::cout << "Candidate " << c << ": " << counts[c] << " votes\n";
    }


    int winner = 1;
    for(int c = 2; c <= 5; c++) {
        if(counts[c] > counts[winner]) {
            winner = c;
        }
    }

    std::cout << "\nWinner: Candidate " << winner << std::endl;

    return 0;
}

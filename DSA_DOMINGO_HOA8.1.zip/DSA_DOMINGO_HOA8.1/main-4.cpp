#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorting.h"
using namespace std;

void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    cout << endl;
}

int main() {
    srand(time(0));
    const int SIZE = 100;
    int arr[SIZE];

    // Generate random array
    for (int i = 0; i < SIZE; i++) arr[i] = rand() % 100;

    cout << "Original Array:\n";
    printArray(arr, SIZE);

    // Shell Sort
    int shellArr[SIZE];
    copy(arr, arr + SIZE, shellArr);
    shellSort(shellArr, SIZE);
    cout << "\nShell Sort Result:\n";
    printArray(shellArr, SIZE);

    // Merge Sort
    int mergeArr[SIZE];
    copy(arr, arr + SIZE, mergeArr);
    mergeSort(mergeArr, 0, SIZE - 1);
    cout << "\nMerge Sort Result:\n";
    printArray(mergeArr, SIZE);

    // Quick Sort
    int quickArr[SIZE];
    copy(arr, arr + SIZE, quickArr);
    quickSort(quickArr, 0, SIZE - 1);
    cout << "\nQuick Sort Result:\n";
    printArray(quickArr, SIZE);


    // SUPPLEMENTARY ACTIVITY 2
    cout << "\nSupplementary Problem 2:\n";
    int supArr2[] = {4, 34, 29, 48, 53, 87, 12, 30, 44, 25, 93, 67, 43, 19, 74};
    int n2 = sizeof(supArr2)/sizeof(supArr2[0]);
    cout << "Original: "; printArray(supArr2, n2);

    quickSort(supArr2, 0, n2 - 1);
    cout << "Quick Sort Result: "; printArray(supArr2, n2);

    return 0;
}

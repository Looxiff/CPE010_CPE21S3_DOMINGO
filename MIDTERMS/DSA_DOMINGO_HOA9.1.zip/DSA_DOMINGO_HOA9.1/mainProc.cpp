#include <iostream>
#include "BST.h"

int main()
{
    // ILO A
    BinarySearchTree<char>* tree =
        new BinarySearchTree<char>('A');

    tree->insert('B');
    tree->insert('C');
    tree->insert('D');
    tree->insert('E');
    tree->insert('F');
    tree->insert('G');

    //TASK 3.4 in ILO B
    tree->insert('O');

    tree->insert('H');
    tree->insert('I');
    tree->insert('J');
    tree->insert('K');
    tree->insert('L');
    tree->insert('M');
    tree->insert('N');
    tree->insert('P');
    tree->insert('Q');

    std::cout << " ILO A " << std::endl;
    std::cout << "Tree successfully created!" << std::endl;

    // ILO B
    std::cout << "\n ILO B " << std::endl;

    std::cout << "Pre order: ";
    tree->preOrder();

    std::cout << "\n\nIn order: ";
    tree->inOrder();

    std::cout << "\n\nPost order: ";
    tree->postOrder();

    std::cout << std::endl;

    //Task 3.3
    std::cout<<"\nFinding Q" << std::endl;
    tree->findData('Q');

    //TASK 3.4
    std::cout<<"\nFinding 0" << std::endl;
    tree->findData('O');

    return 0;
}
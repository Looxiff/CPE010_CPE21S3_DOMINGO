#include <iostream>

// bullet 1
int twoNum(int fx, int gx);
void threeNum (int fx, int gx, int hx );

// bullet 2
void AbetterB(int A, int B);

// bullet 3
bool logic(bool C, bool D);

int main(){
	
	std::cout<< "A.1:" <<std::endl;
	std::cout<< twoNum(6, 9) << std::endl;
	threeNum(1,2,3);
	
	std::cout<< "\n";
	
	std::cout << "B.1:" <<std::endl;
	AbetterB(50, 40);
	std::cout <<"\n"; 
	
	std::cout << "C.1: " <<std::endl;
	bool sus = logic(true , false);
	
	return 0;
}

int twoNum(int fx, int gx){
	
	int sum = fx + gx;
	
	return sum;
	
}
void threeNum (int fx, int gx, int hx ){
	
	std::cout << fx + gx + hx << std::endl;
}

void AbetterB(int A, int B){
	if(A > B){
		std::cout <<" A is greater than B" << std::endl;
		
	}
	
	else if(A < B){
		std::cout <<"A is NOT greater than B" << std::endl;
		
	}
	
}

bool logic(bool C, bool D){
	
	std::cout << "AND logic (C && D): " << C && D;
	std::cout << "\n";
	
	std::cout << "OR logic (C || D): " << C || D;
	std::cout << "\n";
	
	std::cout << "NOT logic !(C): " << !(C);
	std::cout << "\n";
	
	std::cout << "NOT logic !(D): " << !(D);
	std::cout << "\n";
	return true;
	
	
}


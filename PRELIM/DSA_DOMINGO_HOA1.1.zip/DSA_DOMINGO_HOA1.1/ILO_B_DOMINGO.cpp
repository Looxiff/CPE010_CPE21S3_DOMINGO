#include <iostream>


class Triangle{
	private:
		double totalAngle, angleA, angleB, angleC;
	public:
		Triangle(double A, double B, double C);
		void setAngles(double A, double B, double C);
		const bool validationTriangle();
};

int main() {
	
	Triangle setl(40,30,110);
	
	if(setl.validationTriangle()){
		std::cout<<"shape is valid triangle";
	} else{
		std::cout<<"not a valid triangle";
	}
	
	return 0;
}

Triangle::Triangle(double A, double B, double C){
	angleA = A;
	angleB = B;
	angleC = C;
	totalAngle = A+B+C;
}

void Triangle::setAngles(double A, double B, double C){
	angleA = A;
	angleB = B;
	angleC = C;
	totalAngle = A+B+C;
}

const bool Triangle::validationTriangle(){
	return(totalAngle <= 180);
}

#include <iostream>

int main() {
    int a = 10;
    int b = 20;
    int temp;

    std::cout << "Before Swapping:\n";
    std::cout << "a = " << a << "\n";
    std::cout << "b = " << b << "\n";

    temp = a;
    a = b;
    b = temp;

    std::cout << "\nAfter Swapping:\n";
    std::cout << "a = " << a << "\n";
    std::cout << "b = " << b << "\n";

    return 0;
}
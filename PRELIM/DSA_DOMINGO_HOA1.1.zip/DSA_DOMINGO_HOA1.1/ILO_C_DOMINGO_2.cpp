#include <iostream>

double kelvinToFahrenheit(double kelvin);

int main() {
    double kelvin = 300;

    std::cout << "Temperature in Kelvin: "
              << kelvin << std::endl;

    std::cout << "Temperature in Fahrenheit: "
              << kelvinToFahrenheit(kelvin)
              << std::endl;

    return 0;
}

double kelvinToFahrenheit(double kelvin) {
    return (kelvin - 273.15) * 9.0 / 5.0 + 32;
}
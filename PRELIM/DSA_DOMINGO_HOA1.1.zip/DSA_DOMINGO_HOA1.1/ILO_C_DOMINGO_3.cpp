#include <iostream>
#include <cmath>

double distance(double x1, double y1,
                double x2, double y2);

int main() {

    double x1 = 2;
    double y1 = 3;
    double x2 = 8;
    double y2 = 7;

    std::cout << "Distance = "
              << distance(x1, y1, x2, y2)
              << std::endl;

    return 0;
}

double distance(double x1, double y1,
                double x2, double y2) {

    return std::sqrt(
        std::pow(x2 - x1, 2) +
        std::pow(y2 - y1, 2)
    );
}
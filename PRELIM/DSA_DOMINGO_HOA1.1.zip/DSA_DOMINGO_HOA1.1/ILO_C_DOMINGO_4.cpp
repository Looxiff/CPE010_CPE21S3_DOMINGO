#include <iostream>
#include <cmath>

class Triangle{
    private:
        double sideA, sideB, sideC;

    public:
        Triangle(double A, double B, double C);
        void setSides(double A, double B, double C);
        const bool validationTriangle();
        double area();
        double perimeter();
        void triangleType();
};

int main(){

    Triangle set1(3,4,5);

    if(set1.validationTriangle()){
        std::cout << "Shape is a valid triangle.\n";
        std::cout << "Perimeter: " << set1.perimeter() << std::endl;
        std::cout << "Area: " << set1.area() << std::endl;
        set1.triangleType();
    }
    else{
        std::cout << "Not a valid triangle.";
    }

    return 0;
}

Triangle::Triangle(double A, double B, double C){
    sideA = A;
    sideB = B;
    sideC = C;
}

void Triangle::setSides(double A, double B, double C){
    sideA = A;
    sideB = B;
    sideC = C;
}

const bool Triangle::validationTriangle(){
    return ((sideA + sideB > sideC) &&
            (sideA + sideC > sideB) &&
            (sideB + sideC > sideA));
}

double Triangle::perimeter(){
    return sideA + sideB + sideC;
}

double Triangle::area(){
    double s = perimeter() / 2;
    return std::sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
}

void Triangle::triangleType(){

    double a = sideA;
    double b = sideB;
    double c = sideC;

    // Make c the longest side
    if(a > c){
        double temp = a;
        a = c;
        c = temp;
    }

    if(b > c){
        double temp = b;
        b = c;
        c = temp;
    }

    double a2 = a * a;
    double b2 = b * b;
    double c2 = c * c;

    if(c2 < a2 + b2){
        std::cout << "Triangle Type: Acute Triangle";
    }
    else if(c2 > a2 + b2){
        std::cout << "Triangle Type: Obtuse Triangle";
    }
    else{
        std::cout << "Triangle Type: Others (Right Triangle)";
    }
}
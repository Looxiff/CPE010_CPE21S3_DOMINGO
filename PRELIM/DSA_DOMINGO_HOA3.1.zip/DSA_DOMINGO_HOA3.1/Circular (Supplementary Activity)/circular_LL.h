#ifndef CIRCULAR_LL_H
#define CIRCULAR_LL_H

#include <iostream>
#include <string>

template<typename T>
class SongNode{
public:
    T songTitle;
    SongNode<T>* next;

    SongNode(T title){
        songTitle = title;
        next = nullptr;
    }
};

// Create a Song Node
template<typename T>
SongNode<T>* createSong(T title){
    SongNode<T>* newSong = new SongNode<T>(title);
    return newSong;
}

// Add Song to Playlist
template<typename T>
void addSong(T title, SongNode<T>** head){

    SongNode<T>* newSong = createSong(title);

    // Empty playlist
    if(*head == nullptr){
        *head = newSong;
        newSong->next = newSong;
        return;
    }

    SongNode<T>* temp = *head;

    while(temp->next != *head){
        temp = temp->next;
    }

    temp->next = newSong;
    newSong->next = *head;
}

// Display Playlist
template<typename T>
void displayPlaylist(SongNode<T>* head){

    if(head == nullptr){
        std::cout << "Playlist is empty.\n";
        return;
    }

    SongNode<T>* temp = head;

    std::cout << "\nPlaylist:\n";

    do{
        std::cout << temp->songTitle << std::endl;
        temp = temp->next;
    }
    while(temp != head);
}

// Remove Song
template<typename T>
void removeSong(T title, SongNode<T>** head){

    if(*head == nullptr){
        std::cout << "Playlist is empty.\n";
        return;
    }

    SongNode<T>* current = *head;
    SongNode<T>* previous = nullptr;

    // Remove head
    if(current->songTitle == title){

        // Only one song
        if(current->next == *head){
            delete current;
            *head = nullptr;
            return;
        }

        SongNode<T>* last = *head;

        while(last->next != *head){
            last = last->next;
        }

        *head = current->next;
        last->next = *head;

        delete current;
        return;
    }

    previous = current;
    current = current->next;

    while(current != *head && current->songTitle != title){
        previous = current;
        current = current->next;
    }

    if(current == *head){
        std::cout << "Song not found.\n";
        return;
    }

    previous->next = current->next;
    delete current;
}

// Play All Songs
template<typename T>
void playAllSongs(SongNode<T>* head){

    if(head == nullptr){
        std::cout << "Playlist is empty.\n";
        return;
    }

    SongNode<T>* temp = head;

    std::cout << "\nPlaying Playlist\n";

    do{
        std::cout << "Playing: " << temp->songTitle << std::endl;
        temp = temp->next;
    }
    while(temp != head);
}

// Next Song
template<typename T>
void nextSong(SongNode<T>** current){

    if(*current == nullptr){
        std::cout << "Playlist is empty.\n";
        return;
    }

    *current = (*current)->next;

    std::cout << "Now Playing: "
              << (*current)->songTitle
              << std::endl;
}

// Previous Song
template<typename T>
void previousSong(SongNode<T>* head, SongNode<T>** current){

    if(head == nullptr){
        std::cout << "Playlist is empty.\n";
        return;
    }

    SongNode<T>* temp = head;

    while(temp->next != *current){
        temp = temp->next;
    }

    *current = temp;

    std::cout << "Now Playing: "
              << (*current)->songTitle
              << std::endl;
}

// Delete Playlist
template<typename T>
void deletePlaylist(SongNode<T>** head){

    if(*head == nullptr)
        return;

    SongNode<T>* current = (*head)->next;

    while(current != *head){
        SongNode<T>* temp = current;
        current = current->next;
        delete temp;
    }

    delete *head;
    *head = nullptr;
}

#endif
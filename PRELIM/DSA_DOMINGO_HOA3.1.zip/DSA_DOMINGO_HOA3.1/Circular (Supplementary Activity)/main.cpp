#include <iostream>
#include <string>
#include "circular_LL.h"

int main(){

    SongNode<std::string>* head = nullptr;
    SongNode<std::string>* current = nullptr;

    // Create Playlist
    addSong<std::string>("Beyond the Station - HOYO-mix", &head);
    addSong<std::string>("Perfect - Ed Sheeran", &head);
    addSong<std::string>("Circles - Post Malone", &head);
    addSong<std::string>("We don't talk anymore - Charlie Puth, Selena Gomez", &head);

    current = head;

    std::cout << "===== PLAYLIST CREATED =====" << std::endl;
    displayPlaylist(head);

    // Add Song
    std::cout << "\n===== ADD SONG =====" << std::endl;
    addSong<std::string>("Shape of You", &head);
    displayPlaylist(head);

    // Remove Song
    std::cout << "\n===== REMOVE SONG =====" << std::endl;
    removeSong<std::string>("Stay", &head);
    displayPlaylist(head);

    // Play All Songs
    std::cout << "\n===== PLAY ALL SONGS =====" << std::endl;
    playAllSongs(head);

    // Next Song
    std::cout << "\n===== NEXT SONG =====" << std::endl;
    nextSong(&current);

    // Next Song Again
    std::cout << "\n===== NEXT SONG =====" << std::endl;
    nextSong(&current);

    // Previous Song
    std::cout << "\n===== PREVIOUS SONG =====" << std::endl;
    previousSong(head, &current);

    // Display Final Playlist
    std::cout << "\n===== FINAL PLAYLIST =====" << std::endl;
    displayPlaylist(head);

    // Delete Playlist
    std::cout << "\n===== DELETE PLAYLIST =====" << std::endl;
    deletePlaylist(&head);

    displayPlaylist(head);

    return 0;
}
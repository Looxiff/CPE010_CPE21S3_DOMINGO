#ifndef DOUBLE_LL_H
#define DOUBLE_LL_H

#include <iostream>

template<typename T>
class DoubleList{
public:
    T data;
    DoubleList<T>* prev = nullptr;
    DoubleList<T>* next = nullptr;
};

// Create Node
template<typename T>
DoubleList<T>* createNode(T newData){
    DoubleList<T>* newNode = new DoubleList<T>;

    newNode->data = newData;
    newNode->prev = nullptr;
    newNode->next = nullptr;

    return newNode;
}

// Traverse Forward and Backward
template<typename T>
void dllTraverse(DoubleList<T>* currentNode){
    if(currentNode == nullptr){
        std::cout << "The list is empty." << std::endl;
        return;
    }

    DoubleList<T>* tail = nullptr;

    std::cout << "Forward: ";
    while(currentNode != nullptr){
        std::cout << currentNode->data << " ";
        tail = currentNode;
        currentNode = currentNode->next;
    }

    std::cout << "\nBackward: ";
    while(tail != nullptr){
        std::cout << tail->data << " ";
        tail = tail->prev;
    }

    std::cout << std::endl;
}

// Reverse Traverse Only
template<typename T>
void dllReverseTraverse(DoubleList<T>* head){
    if(head == nullptr){
        std::cout << "The list is empty." << std::endl;
        return;
    }

    while(head->next != nullptr)
        head = head->next;

    while(head != nullptr){
        std::cout << head->data << " ";
        head = head->prev;
    }

    std::cout << std::endl;
}

// Insert at Head
template<typename T>
void dllInsertHead(T newData, DoubleList<T>** head){
    DoubleList<T>* newNode = createNode(newData);

    newNode->next = *head;

    if(*head != nullptr)
        (*head)->prev = newNode;

    *head = newNode;
}

// Insert at End
template<typename T>
void dllInsertEnd(T newData, DoubleList<T>** head){
    DoubleList<T>* newNode = createNode(newData);

    if(*head == nullptr){
        *head = newNode;
        return;
    }

    DoubleList<T>* temp = *head;

    while(temp->next != nullptr)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

// General Insert (After Given Node)
template<typename T>
void dllGenIns(T newData, DoubleList<T>* prevNode){
    if(prevNode == nullptr){
        std::cout << "Previous node cannot be empty." << std::endl;
        return;
    }

    DoubleList<T>* newNode = createNode(newData);

    newNode->next = prevNode->next;
    newNode->prev = prevNode;

    if(prevNode->next != nullptr)
        prevNode->next->prev = newNode;

    prevNode->next = newNode;
}

// Insert Before Given Node
template<typename T>
void dllInsertBefore(T newData, DoubleList<T>* nextNode, DoubleList<T>** head){
    if(nextNode == nullptr)
        return;

    DoubleList<T>* newNode = createNode(newData);

    newNode->prev = nextNode->prev;
    newNode->next = nextNode;

    if(nextNode->prev != nullptr)
        nextNode->prev->next = newNode;
    else
        *head = newNode;

    nextNode->prev = newNode;
}

// Search Node
template<typename T>
DoubleList<T>* dllSearch(T findData, DoubleList<T>* head){
    while(head != nullptr){
        if(head->data == findData)
            return head;

        head = head->next;
    }

    return nullptr;
}

// Count Nodes
template<typename T>
int dllCount(DoubleList<T>* head){
    int count = 0;

    while(head != nullptr){
        count++;
        head = head->next;
    }

    return count;
}

// Delete Head
template<typename T>
void dllDeleteHead(DoubleList<T>** head){
    if(*head == nullptr)
        return;

    DoubleList<T>* temp = *head;
    *head = temp->next;

    if(*head != nullptr)
        (*head)->prev = nullptr;

    delete temp;
}

// Delete End
template<typename T>
void dllDeleteEnd(DoubleList<T>** head){
    if(*head == nullptr)
        return;

    DoubleList<T>* temp = *head;

    if(temp->next == nullptr){
        delete temp;
        *head = nullptr;
        return;
    }

    while(temp->next != nullptr)
        temp = temp->next;

    temp->prev->next = nullptr;
    delete temp;
}

// Delete Specific Node
template<typename T>
void dllDeleteNode(T findData, DoubleList<T>** head){
    if(*head == nullptr)
        return;

    DoubleList<T>* current = *head;

    while(current != nullptr && current->data != findData)
        current = current->next;

    if(current == nullptr)
        return;

    if(current == *head){
        *head = current->next;

        if(*head != nullptr)
            (*head)->prev = nullptr;
    }
    else{
        current->prev->next = current->next;

        if(current->next != nullptr)
            current->next->prev = current->prev;
    }

    delete current;
}

// Delete Entire List
template<typename T>
void dllDeleteList(DoubleList<T>** head){
    DoubleList<T>* current = *head;

    while(current != nullptr){
        DoubleList<T>* temp = current;
        current = current->next;
        delete temp;
    }

    *head = nullptr;
}

#endif
#include <iostream>
#include "simply_LL.h"
#include "double_LL.h"

int main(){

    // Creating the first nodes: C -> P -> E
    DoubleList<char>* head = createNode('C');
    DoubleList<char>* second = createNode('P');
    DoubleList<char>* third = createNode('E');

    // Link the nodes together
    head->next = second;
    second->prev = head;

    second->next = third;
    third->prev = second;

    // Traversal
    std::cout << "Traversal testing:" << std::endl;
    dllTraverse(head);

    // Insert at Head
    std::cout << "\nInsert Head testing:" << std::endl;
    dllInsertHead('X', &head);
    dllTraverse(head);

    // Insert at End
    std::cout << "\nInsert End testing:" << std::endl;
    dllInsertEnd('1', &head);
    dllTraverse(head);

    // General Insertion
    std::cout << "\nGeneral Insertion testing:" << std::endl;
    dllGenIns('H', head);
    dllGenIns('Y', second);
    dllTraverse(head);

    // Search
    std::cout << "\nSearch testing:" << std::endl;
    DoubleList<char>* found = dllSearch('P', head);

    if(found != nullptr){
        std::cout << "Found node: " << found->data << std::endl;
    }
    else{
        std::cout << "Node not found." << std::endl;
    }

    // Count
    std::cout << "\nCount testing:" << std::endl;
    std::cout << "Total Nodes: " << dllCount(head) << std::endl;

    // Reverse Traversal
    std::cout << "\nReverse Traversal testing:" << std::endl;
    dllReverseTraverse(head);

    // Insert Before
    std::cout << "\nInsert Before testing:" << std::endl;
    dllInsertBefore('Z', second, &head);
    dllTraverse(head);

    // Delete Head
    std::cout << "\nDelete Head testing:" << std::endl;
    dllDeleteHead(&head);
    dllTraverse(head);

    // Delete End
    std::cout << "\nDelete End testing:" << std::endl;
    dllDeleteEnd(&head);
    dllTraverse(head);

    // Delete Specific Node
    std::cout << "\nDelete Specific Node testing:" << std::endl;
    dllDeleteNode('H', &head);
    dllTraverse(head);

    // Delete Entire List
    std::cout << "\nDelete Whole List testing:" << std::endl;
    dllDeleteList(&head);
    dllTraverse(head);

    return 0;
}
#include <iostream>
#include "simply_LL.h"


int main(){

    //creating an empty list
    SimplyList<char>* head = new SimplyList<char>;
    SimplyList<char>* second = new SimplyList<char>;
    SimplyList<char>* third = new SimplyList<char>;
    SimplyList<char>* fourth = new SimplyList<char>;
    SimplyList<char>* fifth = new SimplyList<char>;
    SimplyList<char>* sixth = new SimplyList<char>;

    //assign the data
    head->data = 'C';
    head->next = second;

    second->data = 'P';
    second->next = third;

    third->data = 'E';
    third->next = fourth;

    fourth->data = '0';
    fourth->next = fifth;

    fifth->data = '1';
    fifth->next = sixth;

    sixth->data = '0';
    sixth->next = nullptr;

    std::cout<<"original list:"<<std::endl;
    listTraversal(head);
    std::cout<<"Inserting new node at the head: \n" <<std::endl;
    sllinsertHead('Y', &head);
    listTraversal(head);
    std::cout <<"inserting a new node at the thrid: \n" <<std::endl;
    sllGeneralInsert('X', head->next->next);
    listTraversal(head);

    std::cout <<"inserting new node at the end: \n" <<std::endl;
    sllinsertEnd('U', &head);
    listTraversal(head);

    std::cout<<"deleting a node: \n" << std::endl;
    sllDeleteNode('X',&head);
    listTraversal(head);

    std::cout<<"deleting a head node: \n" << std::endl;
    sllDeleteNode('Y',&head);
    listTraversal(head);

    std::cout<<"deleting a end node: \n" << std::endl;
    sllDeleteNode('U', &head);
    listTraversal(head);

    std::cout<<"deleting all node: \n" << std::endl;
    sllDeleteList(&head);
    listTraversal(head);
    return 0;

}
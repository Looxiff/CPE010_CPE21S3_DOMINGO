#ifndef LISTSTACK_H
#define LISTSTACK_H

//class node with data and next member
template <typename T>
class Node{
    public:
    T data;
    Node<T>* next = nullptr;

};

//create a pointer/reference tip that points to current top node

//global decle
template <typename T>
Node<T>* head = nullptr;

//view
template <typename T>
void push(T newData){
    Node<T>* newNode = new Node<T>;
    newNode->data = newData;
    newNode->next = head<T>;
    head<T> = newNode;
}

template <typename T>
bool isEmpty(){
    return head<T> == nullptr;   
}

template <typename T>
T pop(){
    if(isEmpty<T>()){
        std::cout<<"Stack underflow"<<std::endl;
    }


    // CREATE node
    Node<T>* temp = head<T>;
    //saving a current top node to temp variable
    T tempVal = temp->data;
    
    head<T> = head<T> ->next;

    delete temp;

    return tempVal;
}


template <typename T>
void Top(){
    std::cout<<"The top is: " << head<T> -> data<< std::endl;
}

template <typename T>
void displayALL() {
    if (isEmpty<T>()) {
        std::cout << "LIST is empty" << std::endl;
        return;
    }
    Node<T>* temp = head<T>;
    while (temp != nullptr) {
        std::cout << temp->data << " ";
        temp = temp->next;
    }
    std::cout << std::endl;
}

#endif
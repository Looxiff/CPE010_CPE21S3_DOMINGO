#include <iostream>

const size_t maxCap = 100;
int stack[maxCap];
int top = -1, newData, elements;
int choice;

//prototyping
void push();
void pop();
void Top();
bool isFull();
bool isEmpty();
//display all
void displayAll();

int main(){
    std::cout<<"enter the number of maximum elements for the new stack (max: 100): ";
    std::cin >> elements;

    while(true){
        std::cout<< "Stack Operations: " <<std::endl;
        std::cout<<"1. PUSH \n2. POP \n3. Top\n4. isEmpty \n5. isFull \n6. Display All"<<std::endl;
        std::cin >> choice;

        switch(choice){
            case 1: 
                push();
                break;

            case 2: 
                pop();
                break;

            case 3: 
                Top();
                break;
            case 4: 
                std::cout << isEmpty() <<std::endl;
                break;

            case 5: 
                std::cout <<isFull() << std::endl;
                break;

            case 6: 
                displayAll();
                break;

            default: 
                std::cout<<"Invaild Choice" <<std::endl;
                break;

        }

    }

    return 0;
}

bool isEmpty(){
    //top is -1
    if(top == -1){
        std::cout<<"Stack underflow\n";
        return true;
    } 
    return false;
}

bool isFull(){
    //not equal to the maxCap
    if(top >= elements - 1){
        std::cout<<"Stack overflow";
        return true;
    }
    return false;

}


void push(){

    //check if the stack is full, if yes return an error
    if(isFull()) return;
    //ask the user for a value to be pushed into the stack
    std::cout<<"What number you want to add tot the stack? ";
    std::cin >> newData;
    //store inside the stack?
    stack[++top] = newData;

}

void pop(){

    //check if there are no more elements inside the stack
    if(isEmpty()) return;

    //display the element to be popped:
    std::cout<<"Popping: " <<stack[top] <<std::endl;

    //decremenet the top?
    top--;

}

void Top(){
    //error checking?
    if(isEmpty()) return;

    //diplay the top element
    std::cout<<"Top element: " <<stack[top]<<std::endl;

}

void displayAll(){
    if (top == -1) {
        std::cout << "Stack is empty." << std::endl;
        return;
    }

    std::cout << "Displaying all elements (Top to Bottom):" << std::endl;
    for (int i = top; i >= 0; i--) {
        std::cout << stack[i] << std::endl;
    }
}
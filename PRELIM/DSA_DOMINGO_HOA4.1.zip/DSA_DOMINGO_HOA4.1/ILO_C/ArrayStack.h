#ifndef ARRAYSTACK_H
#define ARRAYSTACK_H

template <typename T>
class ArrayStack {
public:
    static const int MAX = 100;
    T stackArr[MAX];
    int top;

    ArrayStack() : top(-1) {}

    bool isEmpty() {
        return top == -1;
    }

    void push(T value) {
        if (top == MAX - 1) {
            std::cout << "Stack Overflow." << std::endl;
            return;
        }
        stackArr[++top] = value;
    }

    T pop() {
        if (isEmpty()) {
            std::cout << "Stack Underflow." << std::endl;
            return T();
        }
        return stackArr[top--];
    }

    T Top() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return T();
        }
        return stackArr[top];
    }

    void displayAll() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return;
        }
        std::cout << "Stack elements (top to bottom): ";
        for (int i = top; i >= 0; i--) {
            std::cout << stackArr[i] << " ";
        }
        std::cout << std::endl;
    }
};

#endif

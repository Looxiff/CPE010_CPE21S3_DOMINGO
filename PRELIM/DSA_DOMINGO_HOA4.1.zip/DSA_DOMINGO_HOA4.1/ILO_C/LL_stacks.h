#ifndef LL_STACKS_H
#define LL_STACKS_H

template <typename T>
class Node{
    std::cout<<"haha";
}


#endif
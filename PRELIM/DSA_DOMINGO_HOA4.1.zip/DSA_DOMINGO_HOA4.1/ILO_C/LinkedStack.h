#ifndef LINKEDSTACK_H
#define LINKEDSTACK_H

#include <iostream>

template <typename T>
class Node {
public:
    T data;
    Node* next;
    Node(T val) : data(val), next(nullptr) {}
};

template <typename T>
class LinkedStack {
public:
    Node<T>* head;

    LinkedStack() : head(nullptr) {}

    bool isEmpty() {
        return head == nullptr;
    }

    void push(T value) {
        Node<T>* newNode = new Node<T>(value);
        newNode->next = head;
        head = newNode;
    }

    T pop() {
        if (isEmpty()) {
            std::cout << "Stack Underflow." << std::endl;
            return T();
        }
        Node<T>* temp = head;
        T val = temp->data;
        head = head->next;
        delete temp;
        return val;
    }

    T Top() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return T();
        }
        return head->data;
    }

    void displayAll() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return;
        }
        Node<T>* temp = head;
        std::cout << "Stack elements (top to bottom): ";
        while (temp != nullptr) {
            std::cout << temp->data << " ";
            temp = temp->next;
        }
        std::cout << std::endl;
    }
};

#endif

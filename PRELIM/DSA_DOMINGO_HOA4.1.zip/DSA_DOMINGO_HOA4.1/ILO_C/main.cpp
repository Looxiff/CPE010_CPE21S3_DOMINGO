#include <iostream>
#include <string>
#include "LinkedStack.h"

//Array
class ArrayStack{
public:
    static const int MAX = 100;
    char stackArr[MAX];
    int top;

    ArrayStack() : top(-1) {}

    bool isEmpty() { return top == -1; }

    void push(char value) {
        if (top == MAX - 1) {
            std::cout << "Stack Overflow." << std::endl;
            return;
        }
        stackArr[++top] = value;
    }

    char pop() {
        if (isEmpty()) {
            std::cout << "Stack Underflow." << std::endl;
            return '\0';
        }
        return stackArr[top--];
    }

    char Top() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return '\0';
        }
        return stackArr[top];
    }

    void displayAll() {
        if (isEmpty()) {
            std::cout << "Stack is Empty." << std::endl;
            return;
        }
        std::cout << "Stack elements (top to bottom): ";
        for (int i = top; i >= 0; i--) {
            std::cout << stackArr[i] << " ";
        }
        std::cout << std::endl;
    }
};

// Balanced symbol checker for the ArrayStack
bool isBalancedArray(const std::string& expr) {
    ArrayStack stack;
    for (char c : expr) {
        if (c == '(' || c == '{' || c == '[') {
            stack.push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            if (stack.isEmpty()) return false;
            char open = stack.pop();
            if ((c == ')' && open != '(') ||
                (c == '}' && open != '{') ||
                (c == ']' && open != '[')) {
                return false;
            }
        }
    }
    return stack.isEmpty();
}

// Balanced symbol checker for the LinkedStack
bool isBalancedLinked(const std::string& expr) {
    LinkedStack<char> stack;
    for (char c : expr) {
        if (c == '(' || c == '{' || c == '[') {
            stack.push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            if (stack.isEmpty()) return false;
            char open = stack.pop();
            if ((c == ')' && open != '(') ||
                (c == '}' && open != '{') ||
                (c == ']' && open != '[')) {
                return false;
            }
        }
    }
    return stack.isEmpty();
}

int main() {
    std::string expr1 = "(A+B)+(C-D)";
    std::string expr2 = "((A+B)+(C-D)";
    std::string expr3 = "((A+B)+[C-D])";
    std::string expr4 = "((A+B]+[C-D})";

    std::cout << "=== Balanced Symbol Checking ===" << std::endl;
    std::cout << expr1 << " -> ArrayStack: " << (isBalancedArray(expr1) ? "Valid" : "Invalid") << std::endl;
    std::cout << expr2 << " -> ArrayStack: " << (isBalancedArray(expr2) ? "Valid" : "Invalid") << std::endl;
    std::cout << expr3 << " -> LinkedStack: " << (isBalancedLinked(expr3) ? "Valid" : "Invalid") << std::endl;
    std::cout << expr4 << " -> LinkedStack: " << (isBalancedLinked(expr4) ? "Valid" : "Invalid") << std::endl;

    return 0;
}
